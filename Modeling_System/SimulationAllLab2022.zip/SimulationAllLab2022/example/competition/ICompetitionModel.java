package example.competition;


public interface ICompetitionModel {

	public void createTeamsAndStart(IVisualPart ui);

}