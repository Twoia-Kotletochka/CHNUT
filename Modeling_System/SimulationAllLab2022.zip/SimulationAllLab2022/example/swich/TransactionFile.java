package example.swich;

public class TransactionFile {
	private double fileSizeMByte;

	private double bufferedMByte;

	public double getBufferedMByte() {
		return bufferedMByte;
	}

	public void setBufferedMByte(double bufferedMByte) {
		this.bufferedMByte = bufferedMByte;
	}


	public double getFileSizeMByte() {
		return fileSizeMByte;
	}

	public void setFileSizeMByte(double fileSizeMByte) {
		this.fileSizeMByte = fileSizeMByte;
	}

}
