package toLab8_testGradient;

public interface StepTimerViewListener extends java.util.EventListener {
	/**
	 * 
	 * @param newEvent
	 *            java.util.EventObject
	 */
	void FinishTime_caretUpdate(java.util.EventObject newEvent);
}
