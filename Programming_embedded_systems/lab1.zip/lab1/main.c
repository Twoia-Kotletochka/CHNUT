#include <lpc214x.h>



int main(void) {
	void initClocks(void);  
	
	void initPWM1(void);  //1
	void initPWM2(void);  //2
	void initPWM3(void);  //3
	void initPWM4(void);  //4
	void initPWM5(void);  //5
	void initPWM6(void);  //6
	void initPWM7(void);  //7
	void initPWM8(void);  //8
while(1) {;}
}

void initPWM1(void)
{
  IO0PIN = (IO0PIN | (1<<1)); //Pin P0.1
  PWMPCR = 0x0; //Select Single Edge PWM - by default its single Edged so this line can be removed
  PWMPR = 60-1; // 1 micro-second resolution
  PWMMR0 = 10000; // 10ms period duration
  PWMMR4 = 1250; // 0.5ms - pulse duration i.e width (Brigtness level)
  PWMMCR = (1<<1); // Reset PWMTC on PWMMR0 match
  PWMLER = (1<<0)|(1<<4); // update MR0 and MR4
  PWMPCR = (1<<12); // enable PWM output
  PWMTCR = (1<<1) ; //Reset PWM TC & PR
  //Now , the final moment - enable everything
  PWMTCR = (1<<0) | (1<<3); // enable counters and PWM Mode

}

void initPWM2(void)
{
  IO0PIN = (IO0PIN | (1<<2)); //Pin P0.2
  PWMPCR = 0x0; //Select Single Edge PWM - by default its single Edged so this line can be removed
  PWMPR = 60-1; // 1 micro-second resolution
  PWMMR0 = 10000; // 10ms period duration
  PWMMR4 = 2500; // 0.5ms - pulse duration i.e width (Brigtness level)
  PWMMCR = (1<<1); // Reset PWMTC on PWMMR0 match
  PWMLER = (1<<0)|(1<<4); // update MR0 and MR4
  PWMPCR = (1<<12); // enable PWM output
  PWMTCR = (1<<1) ; //Reset PWM TC & PR
  //Now , the final moment - enable everything
  PWMTCR = (1<<0) | (1<<3); // enable counters and PWM Mode
}

void initPWM3(void)
{
  IO0PIN = (IO0PIN | (1<<3));  //Pin P0.3
  PWMPCR = 0x0; //Select Single Edge PWM - by default its single Edged so this line can be removed
  PWMPR = 60-1; // 1 micro-second resolution
  PWMMR0 = 10000; // 10ms period duration
  PWMMR4 = 3750; // 0.5ms - pulse duration i.e width (Brigtness level)
  PWMMCR = (1<<1); // Reset PWMTC on PWMMR0 match
  PWMLER = (1<<0)|(1<<4); // update MR0 and MR4
  PWMPCR = (1<<12); // enable PWM output
  PWMTCR = (1<<1) ; //Reset PWM TC & PR
  //Now , the final moment - enable everything
  PWMTCR = (1<<0) | (1<<3); // enable counters and PWM Mode
}

void initPWM4(void)
{
  IO0PIN = (IO0PIN | (1<<4));  //Pin P0.4
  PWMPCR = 0x0; //Select Single Edge PWM - by default its single Edged so this line can be removed
  PWMPR = 60-1; // 1 micro-second resolution
  PWMMR0 = 10000; // 10ms period duration
  PWMMR4 = 5000; // 0.5ms - pulse duration i.e width (Brigtness level)
  PWMMCR = (1<<1); // Reset PWMTC on PWMMR0 match
  PWMLER = (1<<0)|(1<<4); // update MR0 and MR4
  PWMPCR = (1<<12); // enable PWM output
  PWMTCR = (1<<1) ; //Reset PWM TC & PR
  //Now , the final moment - enable everything
  PWMTCR = (1<<0) | (1<<3); // enable counters and PWM Mode
}

void initPWM5(void)
{
  IO0PIN = (IO0PIN | (1<<5));  //Pin P0.5
  PWMPCR = 0x0; //Select Single Edge PWM - by default its single Edged so this line can be removed
  PWMPR = 60-1; // 1 micro-second resolution
  PWMMR0 = 10000; // 10ms period duration
  PWMMR4 = 6250; // 0.5ms - pulse duration i.e width (Brigtness level)
  PWMMCR = (1<<1); // Reset PWMTC on PWMMR0 match
  PWMLER = (1<<0)|(1<<4); // update MR0 and MR4
  PWMPCR = (1<<12); // enable PWM output
  PWMTCR = (1<<1) ; //Reset PWM TC & PR
  //Now , the final moment - enable everything
  PWMTCR = (1<<0) | (1<<3); // enable counters and PWM Mode
}

void initPWM6(void)
{
  IO0PIN = (IO0PIN | (1<<6));  //Pin P0.6
  PWMPCR = 0x0; //Select Single Edge PWM - by default its single Edged so this line can be removed
  PWMPR = 60-1; // 1 micro-second resolution
  PWMMR0 = 10000; // 10ms period duration
  PWMMR4 = 7500; // 0.5ms - pulse duration i.e width (Brigtness level)
  PWMMCR = (1<<1); // Reset PWMTC on PWMMR0 match
  PWMLER = (1<<0)|(1<<4); // update MR0 and MR4
  PWMPCR = (1<<12); // enable PWM output
  PWMTCR = (1<<1) ; //Reset PWM TC & PR
  //Now , the final moment - enable everything
  PWMTCR = (1<<0) | (1<<3); // enable counters and PWM Mode
}

void initPWM7(void)
{
  IO0PIN = (IO0PIN | (1<<7));  //Pin P0.7
  PWMPCR = 0x0; //Select Single Edge PWM - by default its single Edged so this line can be removed
  PWMPR = 60-1; // 1 micro-second resolution
  PWMMR0 = 10000; // 10ms period duration
  PWMMR4 = 8750; // 0.5ms - pulse duration i.e width (Brigtness level)
  PWMMCR = (1<<1); // Reset PWMTC on PWMMR0 match
  PWMLER = (1<<0)|(1<<4); // update MR0 and MR4
  PWMPCR = (1<<12); // enable PWM output
  PWMTCR = (1<<1) ; //Reset PWM TC & PR
  //Now , the final moment - enable everything
  PWMTCR = (1<<0) | (1<<3); // enable counters and PWM Mode
}

void initPWM8(void)
{
  IO0PIN = (IO0PIN | (1<<8));  //Pin P0.8
  PWMPCR = 0x0; //Select Single Edge PWM - by default its single Edged so this line can be removed
  PWMPR = 60-1; // 1 micro-second resolution
  PWMMR0 = 10000; // 10ms period duration
  PWMMR4 = 500; // 0.5ms - pulse duration i.e width (Brigtness level)
  PWMMCR = (1<<1); // Reset PWMTC on PWMMR0 match
  PWMLER = (1<<0)|(1<<4); // update MR0 and MR4
  PWMPCR = (1<<12); // enable PWM output
  PWMTCR = (1<<1) ; //Reset PWM TC & PR
  //Now , the final moment - enable everything
  PWMTCR = (1<<0) | (1<<3); // enable counters and PWM Mode
}



	void initClocks(void)
{
  PLL0CON = 0x01;   //Enable PLL
  PLL0CFG = 0x24;   //Multiplier and divider setup
  PLL0FEED = 0xAA;  //Feed sequence
  PLL0FEED = 0x55;
  
  while(!(PLL0STAT & 0x00000400)); //is locked?
    
  PLL0CON = 0x03;   //Connect PLL after PLL is locked
  PLL0FEED = 0xAA;  //Feed sequence
  PLL0FEED = 0x55;
  VPBDIV = 0x01;    // PCLK is same as CCLK i.e.60 MHz
}
