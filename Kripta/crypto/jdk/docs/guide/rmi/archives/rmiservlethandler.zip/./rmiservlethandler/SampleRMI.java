/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.1, 1.2_beta
 */

package samplermi;

import java.rmi.*;

/**
 * Remote interface that will help test the ServletHandler servlet.
 * This interface will be implemented by the SampleRMIServer.  
 */
public interface SampleRMI extends java.rmi.Remote {
    /**
     * Test remote method.
     */
    String justPass(String toPass) throws java.rmi.RemoteException;
}

