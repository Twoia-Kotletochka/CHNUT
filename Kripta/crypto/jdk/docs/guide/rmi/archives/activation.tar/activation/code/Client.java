/*
 * Copyright (c) 1998, 1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Sun grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Sun.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL SUN OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF SUN HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 *
 * This software is not designed or intended for use in on-line control of
 * aircraft, air traffic, aircraft navigation or aircraft communications; or in
 * the design, construction, operation or maintenance of any nuclear
 * facility. Licensee represents and warrants that it will not use or
 * redistribute the Software for such purposes.
 */
package examples.activation; 

import java.rmi.*;

public class Client {

    public static void main(String args[]) {

	String server = "localhost";
	if (args.length < 1) {
	    System.out.println ("Usage: java Client <rmihost>");
	    System.exit(1);
	} else {
	    server = args[0];
	}

	// Set a security manager so that the client can 
	// download the activatable object's stub
	//
	System.setSecurityManager(new RMISecurityManager());

	try {

	    String location = "rmi://" + server + "/ActivatableImplementation";

	    // Since you can't create an instance of an interface, what we get 
	    // back from the lookup method is a remote reference to an object
	    // that implements MyRemoteInterface.
	    //  
	    // Then we cast the remote reference (serialized stub instance)
	    // returned from Naming.lookup to a "MyRemoteInterface" so we can
	    // call the interface method(s).    
            //         
	    MyRemoteInterface mri = (MyRemoteInterface)Naming.lookup(location);
	    System.out.println("Got a remote reference to the object that" + 
		" extends Activatable.");

	    // The String "result" will be changed to "Success" by the remote 
	    // method call
	    //
	    String result = "failure";
	    System.out.println("Making remote call to the server");

	    result = (String)mri.callMeRemotely();
	    System.out.println("Returned from remote call");
	    System.out.println("Result: " + result);

	} catch (Exception e) {
		e.printStackTrace();
	}
    }
}

